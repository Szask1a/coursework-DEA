function validation(){
if(document.getElementById("username").value==""){
alert("you must enter a username..");

}

}